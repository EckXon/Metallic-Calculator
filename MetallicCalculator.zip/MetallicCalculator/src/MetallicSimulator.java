class MetallicSimulator {
    public static MetallicArray metallicArray;
    public static double metDisc;
    public static double cloneLuck;
    public static boolean isRecursive;

    public static int cumulativeRolls = 0;
    public static double average;
    public static double standardDeviation;
    public static double[] averages;
    public static double[] standardDeviations;

    public static int getCumulativeRolls() {
        return cumulativeRolls;
    }

    public static double getAverage() {
        return average;
    }

    public static MetallicArray getMetallicArray() {
        return metallicArray;
    }

    public static double getStandardDeviation() {
        return standardDeviation;
    }

    public static String getAverageRolls() {
        String string = "[";
        for (int i = 0; i < averages.length; i++) {
            string += metallicArray.getMetallicName(i) + ": " + averages[i];
            if (i < averages.length - 1) {
                string += ", ";
            }
        }
        return string + "]";
    }

    public static void simulateRolls(int rolls, int precision, boolean resetIndex) {
        resetTemps();
        for (int j = 0; j < precision; j++) {
            if (resetIndex) {
                metallicArray.resetAll();
            }
            for (int i = 0; i < rolls; i++) {
                metallicArray.roll(metDisc, cloneLuck, isRecursive);
                cumulativeRolls++;
            }
            for (int i = 0; i < averages.length; i++) {
                averages[i] += metallicArray.getMetallicLevelAmt(i);
            }
        }
        for (int i = 0; i < averages.length; i++) {
            averages[i] /= precision;
        }
    }

    public static void simulateCompletion(double completion, int precision,
            boolean resetIndex) {
        resetTemps();
        if (completion > 1 || completion < 0) {
            System.out.println("Please enter a valid completion proportion (0-1)");
            return;
        }
        for (int j = 0; j < 0.5 * precision; j++) {
            if (resetIndex) {
                metallicArray.resetAll();
            }
            for (int i = 0; metallicArray.getCompletion() < completion; i++) {
                metallicArray.roll(metDisc, cloneLuck, isRecursive);
                //System.out.println(metallicArray.toString());
            }
            cumulativeRolls += metallicArray.getTrueMetallicRolls();
            //System.out.println(metallicArray.getMetallicScore() + " " + metallicArray.getSilentRolls());
        }
        average = cumulativeRolls / (0.5 * precision);
        for (int j = 0; j < 0.5 * precision; j++) {
            if (resetIndex) {
                metallicArray.resetAll();
            }
            for (int i = 0; metallicArray.getCompletion() < completion; i++) {
                metallicArray.roll(metDisc, cloneLuck, isRecursive);
                //System.out.println(metallicArray.toString());
            }
            standardDeviation += Math.pow(metallicArray.getTrueMetallicRolls() - average,
                    2);
            cumulativeRolls += metallicArray.getTrueMetallicRolls();
            //System.out.println(metallicArray.getMetallicScore() + " " + metallicArray.getSilentRolls());
        }
        average = (double) cumulativeRolls / precision;
        standardDeviation /= (precision * 0.5 - 1);
        standardDeviation = Math.sqrt(standardDeviation);
    }

    public static void setMetallicArray(MetallicArray mA) {
        metallicArray = mA;
    }

    public static void setMetDisc(double mD) {
        metDisc = mD;
    }

    public static void setCloneLuck(double cL) {
        cloneLuck = cL;
    }

    public static void setRecursion(boolean iR) {
        isRecursive = iR;
    }

    public static void updateStats(double mD, double cL, boolean iR) {
        metDisc = mD;
        cloneLuck = cL;
        isRecursive = iR;
    }

    public static void resetTemps() {
        cumulativeRolls = 0;
        average = 0;
        standardDeviation = 0;
        averages = new double[metallicArray.getMetallicLevels() + 1];
    }
}
