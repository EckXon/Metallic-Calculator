import java.util.Scanner;

class ResponseHandler {
  private static Scanner s = new Scanner(System.in);
  
  public static String filterResponse(String[] validResponses, String errorMsg) {
    boolean validResponse = false;
    String response = s.nextLine();
    while (!validResponse) {
      for (int i = 0; i < validResponses.length; i++) {
        if (response.equals(validResponses[i])) {
          validResponse = true;
        }
      }
      if (!validResponse) {
        System.out.println(errorMsg);
        response = s.nextLine();
      }
    }
    return response;
  }

  public static void fabricateResponseInput(String prompt, String[] responseOptions) {
    int counter = 0;
    System.out.println(prompt);
    for (int i = 0; i < responseOptions.length; i++) {
      counter++;
      System.out.println(counter + ". " + responseOptions[i]);
    }
  }

  public static String fabricateResponseSequence(String prompt, String[] responseOptions, String errorMsg) {
    int counter = 0;
    String[] validResponses = new String[responseOptions.length];
    fabricateResponseInput(prompt, responseOptions);
    for (int i = 0; i < responseOptions.length; i++) {
      counter++;
      validResponses[i] = String.valueOf(counter);
    }
    String response = filterResponse(validResponses, errorMsg);
    return response;
  }

  public static double fabricateResponseDouble(String prompt, String errorMsg) {
    boolean validResponse = false;
    double response = 0;
    while (!validResponse) {
      try {
        System.out.println(prompt);
        response = Double.parseDouble(s.nextLine());
        validResponse = true;
      } catch (Exception e) {
        System.out.println(errorMsg);
      }
    }
    return response;
  }

  public static void fabricateColoredResponse(String[] responseOptions, String[] colorOptions, String errorMsg) {
    
  }
}