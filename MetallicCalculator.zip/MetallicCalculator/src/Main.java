import java.util.ArrayList;
import java.util.Scanner;

class Main {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_PINK = "\u001B[38;5;206m";
    public static final String ANSI_LIGHT_YELLOW = "\u001B[38;5;226m";

    public static void main(String[] args) {
        System.out.println("Hello world!");
        Scanner s = new Scanner(System.in);
        ArrayList<MetallicArray> metallicIndex = new ArrayList<MetallicArray>();
        String[] metallicTierNames = { "Normal", "Chrome", "Gold", "Diamond", "Obsidian",
                "Titanium" };
        metallicIndex
                .add(new MetallicArray("Common", 42, 1, metallicTierNames, ANSI_WHITE));
        metallicIndex
                .add(new MetallicArray("Uncommon", 48, 1, metallicTierNames, ANSI_GREEN));
        metallicIndex
                .add(new MetallicArray("Rare", 1000, 1, metallicTierNames, ANSI_CYAN));
        metallicIndex
                .add(new MetallicArray("Epic", 48, 5, metallicTierNames, ANSI_PURPLE));
        metallicIndex.add(new MetallicArray("Legendary", 24, 5, metallicTierNames,
                ANSI_LIGHT_YELLOW));
        metallicIndex
                .add(new MetallicArray("Prodigious", 6, 5, metallicTierNames, ANSI_PINK));
        metallicIndex
                .add(new MetallicArray("Ascended", 6, 5, metallicTierNames, ANSI_BLUE));
        metallicIndex
                .add(new MetallicArray("Mythical", 6, 5, metallicTierNames, ANSI_RED));
        Interactable.setStats(metallicIndex, -1, 0, 0, 0);
        System.out.println("Welcome to the Metallic Simulator!");
        Interactable.initiate();

        /*
         * System.out.println("Please enter your metallic discovery chance");
         * double metDisc = s.nextDouble(); MetallicArray CommonMetallicArray =
         * new MetallicArray(5,42,metDisc); MetallicArray UncommonMetallicArray
         * = new MetallicArray(5,48,metDisc); MetallicArray RareMetallicArray =
         * new MetallicArray(5,60,metDisc); MetallicArray EpicMetallicArray =
         * new MetallicArray(5,48,metDisc); MetallicArray LegendaryMetallicArray
         * = new MetallicArray(5,24,metDisc); MetallicArray
         * ProdigiousMetallicArray = new MetallicArray(5,6,metDisc);
         * MetallicArray AscendedMetallicArray = new MetallicArray(5,6,metDisc);
         * MetallicArray MythicalMetallicArray = new MetallicArray(5,6,metDisc);
         * System.out.println("What would you like to calculate?");
         * System.out.println("1. Rolls until complete");
         * System.out.println("2. Rolls until complete given current metallics"
         * ); System.out.println("3. Completion given rolls"); System.out.
         * println("4. Completion given rolls given current metallics");
         * System.out.println("5. Average rolls until complete"); System.out.
         * println("6. Average rolls until complete given current metallics" );
         * String response = ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7"}
         * ,"Invalid response, please try again (enter a number)"); if
         * (response.equals("1")) { System.out.
         * println("Which metallic index would you like to roll for completion?"
         * ); System.out.println("1. Common");
         * System.out.println("2. Uncommon"); System.out.println("3. Rare");
         * System.out.println("4. Epic"); System.out.println("5. Legendary");
         * System.out.println("6. Prodigious");
         * System.out.println("7. Ascended"); System.out.println("8. Mythical");
         * System.out.println("9. All"); response =
         * ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7","8","9"}
         * ,"Invalid response, please try again (enter a number)"); int
         * totalRolls;
         * System.out.println("How many titaniums would you like to roll for? "
         * ); int intResponse = s.nextInt(); if (response.equals("1")) {
         * totalRolls = CommonMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete common metallic index"); } else
         * if (response.equals("2")) { totalRolls =
         * UncommonMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete uncommon metallic index"); }
         * else if (response.equals("3")) { totalRolls =
         * RareMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete rare metallic index"); } else
         * if (response.equals("4")) { totalRolls =
         * EpicMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete epic metallic index"); } else
         * if (response.equals("5")) { totalRolls =
         * LegendaryMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete legendary metallic index"); }
         * else if (response.equals("6")) { totalRolls =
         * ProdigiousMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete prodigious metallic index"); }
         * else if (response.equals("7")) { totalRolls =
         * AscendedMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete ascended metallic index"); }
         * else if (response.equals("8")) { totalRolls =
         * MythicalMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete mythical metallic index"); }
         * else if (response.equals("9")) { totalRolls =
         * CommonMetallicArray.untilComplete(intResponse) +
         * UncommonMetallicArray.untilComplete(intResponse) +
         * RareMetallicArray.untilComplete(intResponse) +
         * EpicMetallicArray.untilComplete(intResponse) +
         * LegendaryMetallicArray.untilComplete(intResponse) +
         * ProdigiousMetallicArray.untilComplete(intResponse) +
         * AscendedMetallicArray.untilComplete(intResponse) +
         * MythicalMetallicArray.untilComplete(intResponse);
         * System.out.println("It took you " + totalRolls +
         * " metallic rolls to attain a complete metallic index"); } } else if
         * (response.equals("3")) { ArrayList<String> exampleIndex = new
         * ArrayList<String>(); System.out.
         * println("How many rolls would you like to simulate? (enter a number)"
         * ); int intResponse = s.nextInt();
         * System.out.println("Which metallic index would you like to simulate?"
         * ); System.out.println("1. Common");
         * System.out.println("2. Uncommon"); System.out.println("3. Rare");
         * System.out.println("4. Epic"); System.out.println("5. Legendary");
         * System.out.println("6. Prodigious");
         * System.out.println("7. Ascended"); System.out.println("8. Mythical");
         * response = "0"; response = s.nextLine(); response =
         * ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7","8","9"}
         * ,"Invalid response, please try again (enter a number)"); if
         * (response.equals("1")) { CommonMetallicArray.rollIndex(intResponse);
         * exampleIndex = CommonMetallicArray.toStringArray();
         * System.out.println(exampleIndex); } else if (response.equals("2")) {
         * UncommonMetallicArray.rollIndex(intResponse); exampleIndex =
         * UncommonMetallicArray.toStringArray();
         * System.out.println(exampleIndex); } else if (response.equals("3")) {
         * RareMetallicArray.rollIndex(intResponse); exampleIndex =
         * RareMetallicArray.toStringArray(); System.out.println(exampleIndex);
         * } else if (response.equals("4")) {
         * EpicMetallicArray.rollIndex(intResponse); exampleIndex =
         * EpicMetallicArray.toStringArray(); System.out.println(exampleIndex);
         * } else if (response.equals("5")) {
         * LegendaryMetallicArray.rollIndex(intResponse); exampleIndex =
         * LegendaryMetallicArray.toStringArray();
         * System.out.println(exampleIndex); } else if (response.equals("6")) {
         * ProdigiousMetallicArray.rollIndex(intResponse); exampleIndex =
         * ProdigiousMetallicArray.toStringArray();
         * System.out.println(exampleIndex); } else if (response.equals("7")) {
         * AscendedMetallicArray.rollIndex(intResponse); exampleIndex =
         * AscendedMetallicArray.toStringArray();
         * System.out.println(exampleIndex); } else if (response.equals("8")) {
         * MythicalMetallicArray.rollIndex(intResponse); exampleIndex =
         * MythicalMetallicArray.toStringArray();
         * System.out.println(exampleIndex); } } else if (response.equals("2"))
         * {
         * System.out.println("Which metallic index would you like to simulate?"
         * ); System.out.println("1. Common");
         * System.out.println("2. Uncommon"); System.out.println("3. Rare");
         * System.out.println("4. Epic"); System.out.println("5. Legendary");
         * System.out.println("6. Prodigious");
         * System.out.println("7. Ascended"); System.out.println("8. Mythical");
         * response = ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7","8"}
         * ,"Invalid response, please try again (enter a number)");
         * System.out.println("Please enter current amount of normal pets"); int
         * normPetCount = s.nextInt();
         * System.out.println("Please enter current amount of chrome pets"); int
         * chrPetCount = s.nextInt();
         * System.out.println("Please enter current amount of gold pets"); int
         * goldPetCount = s.nextInt();
         * System.out.println("Please enter current amount of diamond pets");
         * int diaPetCount = s.nextInt();
         * System.out.println("Please enter current amount of obsidian pets");
         * int obiPetCount = s.nextInt();
         * System.out.println("How many titaniums would you like to roll for? "
         * ); int intResponse = s.nextInt(); if (response.equals("1")) {
         * System.out.print("It took you " +
         * CommonMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("2")) { System.out.print("It took you " +
         * UncommonMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("3")) { System.out.print("It took you " +
         * RareMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("4")) { System.out.print("It took you " +
         * EpicMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("5")) { System.out.print("It took you " +
         * LegendaryMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("6")) { System.out.print("It took you " +
         * ProdigiousMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("7")) { System.out.print("It took you " +
         * AscendedMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); }
         * else if (response.equals("8")) { System.out.print("It took you " +
         * MythicalMetallicArray.untilCompleteGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount) +
         * " total metallic rolls to complete your common metallic index"); } }
         * else if (response.equals("4")) {
         * System.out.println("Which metallic index would you like to simulate?"
         * ); System.out.println("1. Common");
         * System.out.println("2. Uncommon"); System.out.println("3. Rare");
         * System.out.println("4. Epic"); System.out.println("5. Legendary");
         * System.out.println("6. Prodigious");
         * System.out.println("7. Ascended"); System.out.println("8. Mythical");
         * response = ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7","8"}
         * ,"Invalid response, please try again (enter a number)");
         * System.out.println("Please enter current amount of normal pets"); int
         * normPetCount = s.nextInt();
         * System.out.println("Please enter current amount of chrome pets"); int
         * chrPetCount = s.nextInt();
         * System.out.println("Please enter current amount of gold pets"); int
         * goldPetCount = s.nextInt();
         * System.out.println("Please enter current amount of diamond pets");
         * int diaPetCount = s.nextInt();
         * System.out.println("Please enter current amount of obsidian pets");
         * int obiPetCount = s.nextInt(); System.out.
         * println("How many rolls would you like to simulate? (enter a number)"
         * ); int intResponse = s.nextInt(); if (response.equals("1")) {
         * CommonMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(CommonMetallicArray.toStringArray()); } else if
         * (response.equals("2")) {
         * UncommonMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(UncommonMetallicArray.toStringArray()); } else if
         * (response.equals("3")) {
         * RareMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(RareMetallicArray.toStringArray()); } else if
         * (response.equals("4")) {
         * EpicMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(EpicMetallicArray.toStringArray()); } else if
         * (response.equals("5")) {
         * LegendaryMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(LegendaryMetallicArray.toStringArray()); } else if
         * (response.equals("6")) {
         * ProdigiousMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(ProdigiousMetallicArray.toStringArray()); } else
         * if (response.equals("7")) {
         * AscendedMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(AscendedMetallicArray.toStringArray()); } else if
         * (response.equals("8")) {
         * MythicalMetallicArray.rollIndexGiven(intResponse, normPetCount,
         * chrPetCount, goldPetCount, diaPetCount, obiPetCount);
         * System.out.println(MythicalMetallicArray.toStringArray()); } } else
         * if (response.equals("5")) { System.out.
         * println("Which metallic index would you like to roll for completion?"
         * ); System.out.println("1. Common");
         * System.out.println("2. Uncommon"); System.out.println("3. Rare");
         * System.out.println("4. Epic"); System.out.println("5. Legendary");
         * System.out.println("6. Prodigious");
         * System.out.println("7. Ascended"); System.out.println("8. Mythical");
         * System.out.println("9. All"); response =
         * ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7","8","9"}
         * ,"Invalid response, please try again (enter a number)"); System.out.
         * println("Please enter degree of precision (number of trials)"); int
         * intResponse = s.nextInt();
         * System.out.println("How many titaniums would you like to roll for? "
         * ); int intResponse2 = s.nextInt(); if (response.equals("1")) {
         * System.out.print("It took you an average of " +
         * CommonMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your common metallic index over " +
         * intResponse + " trials"); } else if (response.equals("2")) {
         * System.out.print("It took you an average of " +
         * UncommonMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your uncommon metallic index over " +
         * intResponse + " trials"); } else if (response.equals("3")) {
         * System.out.print("It took you an average of " +
         * RareMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your rare metallic index over " +
         * intResponse + " trials"); } else if (response.equals("4")) {
         * System.out.print("It took you an average of " +
         * EpicMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your epic metallic index over " +
         * intResponse + " trials"); } else if (response.equals("5")) {
         * System.out.print("It took you an average of " +
         * LegendaryMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your legendary metallic index over " +
         * intResponse + " trials"); } else if (response.equals("6")) {
         * System.out.print("It took you an average of " +
         * ProdigiousMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your prodigious metallic index over " +
         * intResponse + " trials"); } else if (response.equals("7")) {
         * System.out.print("It took you an average of " +
         * AscendedMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your ascended metallic index over " +
         * intResponse + " trials"); } else if (response.equals("8")) {
         * System.out.print("It took you an average of " +
         * MythicalMetallicArray.getAverageCompletionRolls(intResponse2,
         * intResponse) +
         * " metallic rolls to complete your mythical metallic index over " +
         * intResponse + " trials"); } else if (response.equals("9")) {
         * System.out.print("It took you an average of " +
         * (CommonMetallicArray.getAverageCompletionRolls(intResponse) +
         * UncommonMetallicArray.getAverageCompletionRolls(intResponse) +
         * RareMetallicArray.getAverageCompletionRolls(intResponse) +
         * EpicMetallicArray.getAverageCompletionRolls(intResponse) +
         * LegendaryMetallicArray.getAverageCompletionRolls(intResponse) +
         * ProdigiousMetallicArray.getAverageCompletionRolls(intResponse) +
         * AscendedMetallicArray.getAverageCompletionRolls(intResponse) +
         * MythicalMetallicArray.getAverageCompletionRolls(intResponse)) +
         * " metallic rolls to complete your metallic index over " + intResponse
         * + " trials"); } } else if (response.equals("6")) { System.out.
         * println("Which metallic index would you like to roll for completion?"
         * ); System.out.println("1. Common");
         * System.out.println("2. Uncommon"); System.out.println("3. Rare");
         * System.out.println("4. Epic"); System.out.println("5. Legendary");
         * System.out.println("6. Prodigious");
         * System.out.println("7. Ascended"); System.out.println("8. Mythical");
         * System.out.println("9. All"); response =
         * ResponseHandler.filterResponse(new
         * String[]{"1","2","3","4","5","6","7","8","9"}
         * ,"Invalid response, please try again (enter a number)");
         * System.out.println("Please enter current amount of normal pets"); int
         * normPetCount = s.nextInt();
         * System.out.println("Please enter current amount of chrome pets"); int
         * chrPetCount = s.nextInt();
         * System.out.println("Please enter current amount of gold pets"); int
         * goldPetCount = s.nextInt();
         * System.out.println("Please enter current amount of diamond pets");
         * int diaPetCount = s.nextInt();
         * System.out.println("Please enter current amount of obsidian pets");
         * int obiPetCount = s.nextInt(); System.out.
         * println("Please enter degree of precision (number of trials)"); int
         * intResponse = s.nextInt();
         * System.out.println("How many titaniums would you like to roll for? "
         * ); int intResponse2 = s.nextInt(); if (response.equals("1")) {
         * System.out.print("It took you an average of " +
         * CommonMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your common metallic index over " +
         * intResponse + " trials"); } else if (response.equals("2")) {
         * System.out.print("It took you an average of " +
         * UncommonMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your uncommon metallic index over " +
         * intResponse + " trials"); } else if (response.equals("3")) {
         * System.out.print("It took you an average of " +
         * RareMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your rare metallic index over " +
         * intResponse + " trials"); } else if (response.equals("4")) {
         * System.out.print("It took you an average of " +
         * EpicMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your epic metallic index over " +
         * intResponse + " trials"); } else if (response.equals("5")) {
         * System.out.print("It took you an average of " +
         * LegendaryMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your legendary metallic index over " +
         * intResponse + " trials"); } else if (response.equals("6")) {
         * System.out.print("It took you an average of " +
         * ProdigiousMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your prodigious metallic index over " +
         * intResponse + " trials"); } else if (response.equals("7")) {
         * System.out.print("It took you an average of " +
         * AscendedMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your ascended metallic index over " +
         * intResponse + " trials"); } else if (response.equals("8")) {
         * System.out.print("It took you an average of " +
         * MythicalMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * " metallic rolls to complete your mythical metallic index over " +
         * intResponse + " trials"); } else if (response.equals("9")) {
         * System.out.print("It took you an average of " +
         * (CommonMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * UncommonMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * RareMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * EpicMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * LegendaryMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * ProdigiousMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * AscendedMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount) +
         * MythicalMetallicArray.getAverageCompletionRollsGiven(intResponse2,
         * intResponse,normPetCount,chrPetCount,goldPetCount,diaPetCount,
         * obiPetCount)) +
         * " metallic rolls to complete your metallic index over " + intResponse
         * + " trials"); } } else if (response.equals("7")) {
         *
         * }
         */
    }
}
