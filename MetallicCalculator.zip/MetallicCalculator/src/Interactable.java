import java.util.ArrayList;

class Interactable {
    public static ArrayList<MetallicArray> metallicIndexArray;
    public static MetallicArray selectedMetallicIndex;
    public static double metLuck;
    public static double metDisc;
    public static double cloneLuck;
    public static boolean isRecursive = true;

    public static void setStats(ArrayList<MetallicArray> metallicIndexArray,
            int selectedIndex, double ml, double md, double cl) {
        Interactable.metallicIndexArray = metallicIndexArray;
        if (selectedIndex >= 0 && selectedIndex < metallicIndexArray.size()) {
            selectedMetallicIndex = metallicIndexArray.get(selectedIndex);
        }
        metLuck = ml;
        metDisc = md;
        cloneLuck = cl;
    }

    public static void initiate() {
        MetallicSimulator.updateStats(metDisc, cloneLuck, isRecursive);
        String response;
        String[] responseOptions = { "Roll for metallics",
                "Calculate current metallic luck", "View current stats", "Update stats",
                "Exit" };
        response = ResponseHandler.fabricateResponseSequence("What would you like to do?",
                responseOptions, "Invalid response, please try again (enter a number)");
        if (response.equals("1")) {
            rollForMetallics();
        } else if (response.equals("2")) {
            calculateMetallicLuck();
        } else if (response.equals("3")) {
            viewStats();
        } else if (response.equals("4")) {
            updateStats();
        } else {
            return;
        }
    }

    public static void rollForMetallics() {
        String response;
        String[] responseOptions = { "Roll a specific value", "Roll for completion",
                "Return" };
        response = ResponseHandler.fabricateResponseSequence(
                "How would you like to roll for metallics?", responseOptions,
                "Invalid response, please try again (enter a number)");
        if (response.equals("1")) {
            rollSpecificValue();
        } else if (response.equals("2")) {
            rollForCompletion();
        } else if (response.equals("3")) {
            initiate();
        }
    }

    public static void rollSpecificValue() {
        String response;
        String[] responseOptions = { "Common", "Uncommon", "Rare", "Epic", "Legendary",
                "Prodigious", "Ascended", "Mythical" };
        response = ResponseHandler.fabricateResponseSequence(
                "What metallic index would you like to roll?", responseOptions,
                "Invalid response, please try again (enter a number)");
        selectedMetallicIndex = metallicIndexArray.get(Integer.parseInt(response) - 1);
        MetallicSimulator.setMetallicArray(selectedMetallicIndex);
        int rolls = (int) ResponseHandler.fabricateResponseDouble(
                "How many rolls would you like to simulate?",
                "Invalid response, please try again (enter a positive integer)");
        int precision = (int) ResponseHandler.fabricateResponseDouble(
                "How many trials would you like to execute?",
                "Invalid response, please try again (enter a number)");
        MetallicSimulator.simulateRolls(rolls, precision, isRecursive);
        completionResults(rolls, precision);
    }

    public static void rollForCompletion() {
        String response;
        String[] responseOptions = { "Common", "Uncommon", "Rare", "Epic", "Legendary",
                "Prodigious", "Ascended", "Mythical" };
        response = ResponseHandler.fabricateResponseSequence(
                "What metallic index would you like to roll?", responseOptions,
                "Invalid response, please try again (enter a number)");
        selectedMetallicIndex = metallicIndexArray.get(Integer.parseInt(response) - 1);
        MetallicSimulator.setMetallicArray(selectedMetallicIndex);
        double ratio = ResponseHandler.fabricateResponseDouble(
                "What percentage of completion would you like to roll for?",
                "Invalid response, please try again (enter a number between 0 and 100)")
                / 100;
        int precision = (int) ResponseHandler.fabricateResponseDouble(
                "How many times would you like to roll?",
                "Invalid response, please try again (enter a number)");
        MetallicSimulator.simulateCompletion(ratio, precision, isRecursive);
        completionResults(ratio, precision);
    }

    public static void calculateMetallicLuck() {
        double pedMetLuck;
        double runeMetLuck;
        double achieveMetLuck;
        String[] responseOptions = { "Yes", "No" };
        pedMetLuck = ResponseHandler.fabricateResponseDouble(
                "What is your metallic luck percentage from the pedestal (cost stones)?",
                "Invalid response, please try again (enter a number)");
        runeMetLuck = ResponseHandler.fabricateResponseDouble(
                "What is your metallic luck multiplier from rune upgrades?",
                "Invalid response, please try again (enter a number)");
        achieveMetLuck = ResponseHandler.fabricateResponseDouble(
                "What is your metallic luck multiplier from achievements?",
                "Invalid response, please try again (enter a number)");
        System.out.println(
                "Your metallic luck is " + (pedMetLuck * runeMetLuck * achieveMetLuck)
                        + "%, or 1 metallic in every "
                        + (100 / (pedMetLuck * runeMetLuck * achieveMetLuck)) + " pets.");
        String response = ResponseHandler.fabricateResponseSequence(
                "Would you like to save this value to the program?", responseOptions,
                "Invalid response, please try again (enter a number)");
        if (response.equals("1")) {
            metLuck = (pedMetLuck * runeMetLuck * achieveMetLuck) / 100;
            initiate();
        } else if (response.equals("2")) {
            initiate();
        }
    }

    public static void viewStats() {
        String response;
        String[] validResponses = { "1" };
        System.out.println("Metallic Luck: " + metLuck + "\nMetallic Discovery Luck: "
                + metDisc + "\nClone Luck: " + cloneLuck + "\nClone Recursion: "
                + isRecursive);
        for (int i = 0; i < metallicIndexArray.size(); i++) {
            System.out.println(metallicIndexArray.get(i).getColor()
                    + metallicIndexArray.get(i).getName() + " Index: "
                    + metallicIndexArray.get(i).toString());
        }
        System.out.print("\u001B[0m");
        if (selectedMetallicIndex == null) {
            System.out.println("Selected Metallic Index: None");
        } else {
            System.out.println(
                    "Selected Metallic Index: " + selectedMetallicIndex.getName());
        }
        System.out.println("1. Return");
        response = ResponseHandler.filterResponse(validResponses,
                "Invalid response, please try again (enter a number)");
        initiate();
    }

    public static void updateStats() {
        String response;
        String[] responseOptions = { "Metallic luck", "Metallic discovery luck",
                "Clone luck", "Clone Recursion", "Current metallic index", "Return" };
        response = ResponseHandler.fabricateResponseSequence(
                "What stat would you like to update?", responseOptions,
                "Invalid response, please try again (enter a number)");
        if (response.equals("1")) {
            metLuck = ResponseHandler.fabricateResponseDouble(
                    "Please enter your metallic luck percentage",
                    "Invalid response, please try again (enter a number)") / 100;
            updateStatsAgain();
        } else if (response.equals("2")) {
            metDisc = ResponseHandler.fabricateResponseDouble(
                    "Please enter your metallic discovery luck percentage",
                    "Invalid response, please try again (enter a number)") / 100;
            MetallicSimulator.setMetDisc(metDisc);
            updateStatsAgain();
        } else if (response.equals("3")) {
            cloneLuck = ResponseHandler.fabricateResponseDouble(
                    "Please enter your clone luck percentage",
                    "Invalid response, please try again (enter a number)") / 100;
            MetallicSimulator.setCloneLuck(cloneLuck);
            updateStatsAgain();
        } else if (response.equals("4")) {
            response = ResponseHandler.fabricateResponseSequence(
                    "Please enter your clone luck state",
                    new String[] { "1. Recursive", "2. Not recursive" },
                    "Invalid response, please try again (enter a number)");
            MetallicSimulator.setRecursion(response.equals("1"));
            isRecursive = response.equals("1");
            updateStatsAgain();
        } else if (response.equals("5")) {
            updateMetallicIndexes();
            updateStatsAgain();
        } else if (response.equals("6")) {
            initiate();
        }
    }

    public static void updateStatsAgain() {
        String response;
        String[] responseOptions = { "Yes", "No" };
        response = ResponseHandler.fabricateResponseSequence(
                "Would you like to update another stat?", responseOptions,
                "Invalid response, please try again (enter a number)");
        if (response.equals("1")) {
            updateStats();
        } else if (response.equals("2")) {
            initiate();
        }
    }

    public static void updateMetallicIndexes() {
        String response;
        String[] responseOptions = { "Common", "Uncommon", "Rare", "Epic", "Legendary",
                "Prodigious", "Ascended", "Mythical" };
        response = ResponseHandler.fabricateResponseSequence(
                "What metallic index would you like to update?", responseOptions,
                "Invalid response, please try again (enter a number)");
        updateMetallicIndex(metallicIndexArray.get(Integer.parseInt(response) - 1));
    }

    public static void updateMetallicIndex(MetallicArray metallicArray) {
        int[] response = new int[metallicArray.getMetallicNames().size() - 1];
        for (int i = 0; i < response.length; i++) {
            response[i] = (int) ResponseHandler.fabricateResponseDouble(
                    "Please enter the amount of "
                            + metallicArray.getMetallicNames().get(i)
                            + " metallics in your " + metallicArray.getName() + " index",
                    "Invalid response, please try again (enter a number)");
        }
        metallicArray.setMetallicArray(response);
        updateMetallicIndexAgain();
    }

    public static void updateMetallicIndexAgain() {
        String response;
        String[] responseOptions = { "Yes", "No" };
        response = ResponseHandler.fabricateResponseSequence(
                "Would you like to update another metallic index?", responseOptions,
                "Invalid response, please try again (enter a number)");
        if (response.equals("1")) {
            updateMetallicIndexes();
        } else if (response.equals("2")) {
            initiate();
        }
    }

    public static void completionResults(double ratio, int precision) {
        System.out.println("Results over " + precision + " trial(s) for " + ratio * 100
                + "% completion:");
        System.out.println("[Total Rolls: " + MetallicSimulator.getCumulativeRolls()
                + ", Average Rolls (per completion): " + MetallicSimulator.getAverage()
                + ", Standard Deviation (rolls): "
                + MetallicSimulator.getStandardDeviation() + "]");
        System.out.println("1. Return");
        String response;
        String[] validResponses = { "1" };
        response = ResponseHandler.filterResponse(validResponses,
                "Invalid response, please try again (enter a number)");
        initiate();
    }

    public static void completionResults(int rolls, int precision) {
        System.out.println(
                "Results over " + precision + " trial(s) for " + rolls + " rolls:");
        System.out
                .println("[Average Tiers: " + MetallicSimulator.getAverageRolls() + "]");
        System.out.println("1. Return");
        String response;
        String[] validResponses = { "1" };
        response = ResponseHandler.filterResponse(validResponses,
                "Invalid response, please try again (enter a number)");
        initiate();
    }
}
