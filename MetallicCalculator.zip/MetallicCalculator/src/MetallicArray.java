import java.util.ArrayList;
import java.awt.color.ICC_Profile;
import java.lang.Math;

class MetallicArray {
  private String name;
  private int capacity;
  private int metallicLevels;
  private ArrayList<String> metallicNames;
  private String metallicColor;
  private int metallicScore;
  private int silentRolls;
  private int trueMetallicRolls;
  private ArrayList<Integer> metallicArray;

  MetallicArray(String name, int capacity, int levels, String[] levelNames, String color) {
    metallicLevels = Math.abs(levels);
    this.capacity = Math.abs(capacity);
    metallicArray = new ArrayList<Integer>();
    for (int i = 0; i < capacity; i++) {
      metallicArray.add(0);
    }
    metallicNames = new ArrayList<String>();
    for (int i = 0; i < levelNames.length; i++) {
      metallicNames.add(levelNames[i]);
    }
    this.name = name;
    metallicColor = color;
  }

  public void setColor(String color) {
    metallicColor = color;
  }

  public void resetIndex() {
    metallicArray.clear();
    for (int i = 0; i < capacity; i++) {
      metallicArray.add(i, 0);
    }
  }

  public void resetAll() {
    resetIndex();
    trueMetallicRolls = 0;
    metallicScore = 0;
    silentRolls = 0;
  }

  public void setMetallicArray(int[] metallics) {
    resetAll();
    for (int i = 0; i < metallicLevels; i++) {
      if (metallics.length > i) {
        for (int j = 0; j > metallics[i]; j++) {
          metallicArray.set(j, i);
        }
      }
    }
  }

  public void roll(double metDisc, double cloneLuck, boolean isRecursive) {
    // random roll
    int randomIndex = (int) (Math.random() * capacity);

    // clone luck
    int clones = 0;
    if (Math.random() < cloneLuck) {
      clones++;
    }
    while (Math.random() < cloneLuck && clones < 9 && isRecursive) {
      clones++;
    }

    // calculations
    boolean isMaxLevel = false;
    if (metDisc > Math.random()) {
      randomIndex = (int) (Math.random() * metallicArray.size());
      addTiers(1 + clones,randomIndex);
      if (metallicArray.get(randomIndex) == metallicLevels) {
        metallicArray.remove(randomIndex);
        isMaxLevel = true;
      }
    } else if (randomIndex < metallicArray.size()) {
      addTiers(1 + clones,randomIndex);
      if (metallicArray.get(randomIndex) == metallicLevels) {
        metallicArray.remove(randomIndex);
        isMaxLevel = true;
      }
    } else {
      silentRolls += 1 + clones;
    }
    trueMetallicRolls++;
  }

  public double getCompletion() {
    return (double) (capacity - metallicArray.size()) / capacity;
  }

  public void addTiers(int tiers, int index) {
    if (metallicArray.get(index) + tiers <= metallicLevels) {
      metallicArray.set(index, metallicArray.get(index) + tiers);
      metallicScore += tiers;
    } else {
      metallicArray.set(index, metallicLevels);
      silentRolls += tiers - metallicArray.get(index);
    }
  }

  public int getTrueMetallicRolls() {
    return trueMetallicRolls;
  }
    
  public int getMetallicScore() {
    return metallicScore;
  }

  public int getSilentRolls() {
    return silentRolls;
  }

  public int getMetallicLevels() {
    return metallicLevels;
  }

  public String getName() {
    return name;
  }

  public String getColor() {
    return metallicColor;
  }

  public ArrayList<String> getMetallicNames() {
    return metallicNames;
  }

  public String getMetallicName(int level) {
    return metallicNames.get(level);
  }

  public int getMetallicLevelAmt(int level) {
    int count = 0;
    if (level < metallicLevels) {
      for (int i = 0; i < metallicArray.size(); i++) {
        if (metallicArray.get(i) == level) {
          count++;
        }
      }
    } else if (level == metallicLevels) {
      count = capacity - metallicArray.size();
    }
    return count;
  }

  public String toString() {
    int counter = 0;
    String finalString = "[";
    for (int i = 0; i < metallicNames.size(); i++) {
      for (int j = 0; j < metallicArray.size(); j++) {
        if (metallicArray.get(j) == i) {
          counter++;
        }
      }
      if (i != metallicNames.size() - 1) {
        finalString += metallicNames.get(i) + ": " + counter;
        finalString += ", ";
      } else {
        finalString += metallicNames.get(i) + ": " + (capacity - metallicArray.size());
      }
      counter = 0;
    }
    return finalString + "]";
  }
}